```python
import cv2
```


```python
from matplotlib import pyplot as plt
```


```python
img=cv2.imread('yeontan.jpg',0)
```


```python
histr=cv2.calcHist([img],[0],None,[256],[0,256])
```


```python
plt.plot(histr)
plt.show()
```


    
![png](output_4_0.png)
    



```python
# This will import Image and ImageEnhance modules
from PIL import Image, ImageEnhance

# Opening Image
im = Image.open(r"yeontan.jpg")

# Creating object of Brightness class
im3 = ImageEnhance.Brightness(im)


# showing resultant image
im3.enhance(2.0).show()

```


```python
# This will import Image and ImageChops modules
from PIL import Image, ImageEnhance

# Opening Image
im = Image.open(r"yeontan.jpg")

# Creating object of Sharpness class
im3 = ImageEnhance.Sharpness(im)

# showing resultant image
im3.enhance(-2.0).show()

```


```python
import cv2
# import Numpy
import numpy as np
# reading an image using imreadmethod
my_img = cv2.imread('yeontan.jpg', 0)
equ = cv2.equalizeHist(my_img)
# stacking both the images side-by-side orientation
res = np.hstack((my_img, equ))
# showing image input vs output
cv2.imshow('image', res)
cv2.waitKey(0)
cv2.destroyAllWindows()
```


```python
import cv2
# import Numpy
import numpy as np
from matplotlib import pyplot as plt
# reading an image using imreadmethod
my_img = cv2.imread('yeontan.jpg', 0)
equ = cv2.equalizeHist(my_img)
# stacking both the images side-by-side orientation
res = np.hstack((my_img, equ))
# showing image input vs output
cv2.imshow('image', res)
cv2.waitKey(0)
cv2.destroyAllWindows()
hist,bins = np.histogram(equ.flatten(),256,[0,256])
cdf = hist.cumsum()
cdf_normalized = cdf * float(hist.max()) / cdf.max()
plt.plot(cdf_normalized, color = 'b')
plt.hist(equ.flatten(),256,[0,256], color = 'r')
plt.xlim([0,256])
plt.legend(('cdf','histogram'), loc = 'upper left')
plt.show()
```


    
![png](output_8_0.png)
    



```python
from PIL import Image
```


```python
img=Image.open('yeontan.jpg')
```


```python
r,g,b=img.split()
```


```python
len(r.histogram())
```




    256




```python
img.show()
```


```python
g.histogram()
```




    [1077,
     751,
     67,
     25,
     28,
     22,
     28,
     30,
     68,
     137,
     236,
     242,
     242,
     302,
     540,
     480,
     965,
     485,
     358,
     313,
     280,
     284,
     364,
     329,
     341,
     338,
     348,
     377,
     410,
     424,
     391,
     373,
     355,
     347,
     313,
     330,
     309,
     305,
     302,
     257,
     293,
     304,
     281,
     263,
     283,
     304,
     254,
     265,
     292,
     290,
     253,
     243,
     253,
     240,
     233,
     233,
     255,
     202,
     211,
     213,
     226,
     200,
     213,
     170,
     179,
     156,
     164,
     169,
     139,
     167,
     156,
     135,
     146,
     151,
     136,
     133,
     116,
     110,
     146,
     124,
     151,
     119,
     136,
     117,
     124,
     110,
     133,
     128,
     130,
     128,
     119,
     122,
     131,
     130,
     135,
     144,
     137,
     123,
     122,
     119,
     132,
     133,
     135,
     125,
     145,
     136,
     146,
     153,
     151,
     171,
     153,
     193,
     153,
     160,
     202,
     171,
     183,
     168,
     208,
     196,
     213,
     202,
     228,
     222,
     245,
     240,
     250,
     243,
     250,
     261,
     309,
     270,
     254,
     245,
     262,
     237,
     225,
     241,
     252,
     203,
     234,
     230,
     236,
     253,
     211,
     202,
     208,
     209,
     197,
     185,
     188,
     198,
     198,
     191,
     188,
     199,
     178,
     238,
     197,
     216,
     200,
     187,
     208,
     171,
     201,
     225,
     195,
     191,
     179,
     190,
     147,
     202,
     206,
     198,
     200,
     165,
     194,
     229,
     201,
     189,
     204,
     194,
     200,
     196,
     223,
     189,
     240,
     211,
     203,
     331,
     288,
     267,
     282,
     225,
     288,
     250,
     305,
     265,
     273,
     251,
     258,
     294,
     292,
     261,
     247,
     218,
     244,
     241,
     330,
     233,
     242,
     218,
     212,
     171,
     177,
     153,
     149,
     198,
     172,
     131,
     135,
     96,
     93,
     87,
     61,
     61,
     45,
     39,
     38,
     35,
     23,
     27,
     27,
     13,
     20,
     13,
     21,
     15,
     12,
     10,
     9,
     2,
     3,
     2,
     1,
     1,
     1,
     0,
     0,
     0,
     0,
     0,
     0,
     0,
     0,
     0]




```python
width,height=img.size
print(width,height)
```

    164 307
    


```python
import cv2 as cv
img=cv.imread('yeontan.jpg')
print(img)
```

    [[[201 197 202]
      [201 197 202]
      [198 197 201]
      ...
      [140 149 158]
      [144 153 162]
      [149 158 167]]
    
     [[201 197 202]
      [201 197 202]
      [198 197 201]
      ...
      [141 150 159]
      [145 154 163]
      [150 159 168]]
    
     [[201 197 202]
      [201 197 202]
      [198 197 201]
      ...
      [142 151 160]
      [147 156 165]
      [151 160 169]]
    
     ...
    
     [[  3   1   1]
      [  1   1   1]
      [  3   1   1]
      ...
      [  3   1   1]
      [  3   1   1]
      [  3   1   1]]
    
     [[  1   1   1]
      [  1   1   1]
      [  1   1   1]
      ...
      [  1   1   1]
      [  1   1   1]
      [  1   1   1]]
    
     [[  1   1   1]
      [  1   1   1]
      [  1   1   1]
      ...
      [  1   1   1]
      [  1   1   1]
      [  1   1   1]]]
    


```python

```
