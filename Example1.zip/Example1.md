```python

```


```python
pip install opencv-python
```

    Requirement already satisfied: opencv-python in c:\users\user\anaconda3\lib\site-packages (4.5.4.60)
    Requirement already satisfied: numpy>=1.17.3 in c:\users\user\anaconda3\lib\site-packages (from opencv-python) (1.20.1)
    Note: you may need to restart the kernel to use updated packages.
    


```python
# Python program to explain cv2.imshow() method

# importing cv2
import cv2
from matplotlib import pyplot as plt



# Reading an image in default mode
img1 = cv2.imread('yeontan.jpg')

# Window name in which image is displayed
window_name = 'Image'

# Using cv2.imshow() method
# Displaying the image
#image=cv2.cvtColor(image,cv2.COLOR_BGR2HSV)
plt.imshow(img1)

#waits for user to press any key
#(this is necessary to avoid Python kernel form crashing)
cv2.waitKey()

#closing all open windows
cv2.destroyAllWindows()
```


    
![png](output_2_0.png)
    



```python

```


```python
#displaying multiple images
```


```python
import cv2
from matplotlib import pyplot as plt
  
# create figure
fig = plt.figure(figsize=(10, 7))
  
# setting values to rows and column variables
rows = 2
columns = 2



# reading images
Image1 = cv2.imread('yeontan.jpg')
Image2 = cv2.imread('rose.jpg')
Image3 = cv2.imread('jasmine.jpg')
Image4 = cv2.imread('peacock.jpg')
  
# Adds a subplot at the 1st position
fig.add_subplot(rows, columns, 1)
  
# showing image
plt.imshow(Image1)
plt.axis('off')
plt.title("First")
  
# Adds a subplot at the 2nd position
fig.add_subplot(rows, columns, 2)
  
# showing image
plt.imshow(Image2)
plt.axis('off')
plt.title("Second")
  
# Adds a subplot at the 3rd position
fig.add_subplot(rows, columns, 3)
  
# showing image
plt.imshow(Image3)
plt.axis('off')
plt.title("Third")
  
# Adds a subplot at the 4th position
fig.add_subplot(rows, columns, 4)
  
# showing image
plt.imshow(Image4)
plt.axis('off')
plt.title("Fourth")
```




    Text(0.5, 1.0, 'Fourth')




    
![png](output_5_1.png)
    



```python

#scaling
```


```python
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
img = cv.imread('yeontan.jpg')

plt.imshow(img)
res = cv.resize(img,None,fx=2, fy=2, interpolation = cv.INTER_CUBIC)
plt.imshow(res)
cv2.waitKey()
cv2.destroyAllWindows()

```


    
![png](output_7_0.png)
    



```python
#translating and rotation
```


```python
import numpy as np
import cv2 as cv
from matplotlib import pyplot as plt
img = cv.imread('yeontan.jpg',0)
rows,cols = img.shape
M = np.float32([[1,0,100],[0,1,50]])
dst = cv.warpAffine(img,M,(cols,rows))
img = cv.imread('yeontan.jpg',0)
rows,cols = img.shape
# cols-1 and rows-1 are the coordinate limits.
M = cv.getRotationMatrix2D(((cols-1)/2.0,(rows-1)/2.0),90,1)
dst = cv.warpAffine(img,M,(cols,rows))
plt.imshow(dst)
cv.waitKey()
cv.destroyAllWindows()
```


    
![png](output_9_0.png)
    



```python
#Affine Transformation
```


```python
from matplotlib import pyplot as plt
img = cv.imread('yeontan.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[50,50],[200,50],[50,200]])
pts2 = np.float32([[10,100],[200,50],[100,250]])
M = cv.getAffineTransform(pts1,pts2)
dst = cv.warpAffine(img,M,(cols,rows))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


    
![png](output_11_0.png)
    



```python
#Perspective Transformation
```


```python
img = cv.imread('yeontan.jpg')
rows,cols,ch = img.shape
pts1 = np.float32([[56,65],[368,52],[28,387],[389,390]])
pts2 = np.float32([[0,0],[300,0],[0,300],[300,300]])
M = cv.getPerspectiveTransform(pts1,pts2)
dst = cv.warpPerspective(img,M,(300,300))
plt.subplot(121),plt.imshow(img),plt.title('Input')
plt.subplot(122),plt.imshow(dst),plt.title('Output')
plt.show()
```


    
![png](output_13_0.png)
    



```python
#for loops
```


```python
str = "Python"  
for i in str:  
    print(i)  
```

    P
    y
    t
    h
    o
    n
    


```python
list = [1,2,3,4,5,6,7,8,9,10]  
n = 5  
for i in list:  
    if i%2==0:
        c=n*i
        print(c)
print("Multiples Of 5")
```

    10
    20
    30
    40
    50
    Multiples Of 5
    


```python
print("Enter Marks Obtained in 5 Subjects: ")
markOne = int(input())
markTwo = int(input())
markThree = int(input())
markFour = int(input())
markFive = int(input())

tot = markOne+markTwo+markThree+markFour+markFive
avg = tot/5
if markOne<35||markTwo<35||markThree<35||markFour<35||markFive<35:
    print("Fail")
elif avg>=85 and avg<=100:
    print("Your Grade is Distinction")
elif avg>=60 and avg<85:
    print("Your Grade is First Class")
elif avg>=50 and avg<59:
    print("Your Grade is Second Class")
elif avg>=35 and avg<49:
    print("Your Grade is Pass Class")
else:
    print("Invalid Input")
```


      File "<ipython-input-38-abf740a99d19>", line 10
        if markOne<35||markTwo<35||markThree<35||markFour<35||markFive<35:
                      ^
    SyntaxError: invalid syntax
    



```python
weeks=['Monday','Tuesday','Wednesday','Thursday','Friday','Saturday','Sunday']

for x in weeks:
    if x=='Sunday':
     print('No Harish sir class in Sunday')
     continue
    if x=='Monday':
     print('No Harish sir class in Monday')   
     continue
    if x=='Tuesday':
     print('No Harish sir class in Tuesday')   
     continue
    if x=='Saturday':
     print('No Harish sir class in Saturday')   
     continue
    print(x)
```

    No Harish sir class in Monday
    No Harish sir class in Tuesday
    Wednesday
    Thursday
    Friday
    No Harish sir class in Saturday
    No Harish sir class in Sunday
    


```python

```
